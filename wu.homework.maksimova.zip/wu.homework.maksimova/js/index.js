$(document).ready(function(){
    $('.collapsible').collapsible();
});

